import React from 'react';

const lazyload = () => {
  return (
    <div>lazyload</div>
  )
};

export default lazyload;